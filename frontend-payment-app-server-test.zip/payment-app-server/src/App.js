// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;


import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import PaymentButton from './components/PaymentButton';
import SuccessPage from './components/SuccessPage';

function App() {
    return (
        <Router>
            <div className="App">
                <h1>Payment Application</h1>
                <nav>
                    <Link to="/">Home</Link> | <Link to="/complete">Success Page</Link>
                </nav>
                <Routes>
                    <Route path="/" element={<PaymentButton />} />
                    <Route path="/complete" element={<SuccessPage />} />
                    <Route path="/cancel" element={<Navigate to="/" replace />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;



