import React, { useEffect, useState } from 'react';
import axios from 'axios';
// import dotenv from 'dotenv'

// dotenv.config();

const SuccessPage = () => {
    const [sessionId, setSessionId] = useState(null);
    const [paymentStatus, setPaymentStatus] = useState('Processing...');

    useEffect(() => {
        // Extract session_id from the URL query parameters
        const queryParams = new URLSearchParams(window.location.search);
        const sessionIdFromUrl = queryParams.get('session_id');
        console.log("🚀 ~ useEffect ~ sessionIdFromUrl:", sessionIdFromUrl)
        setSessionId(sessionIdFromUrl);

   
        if (sessionIdFromUrl) {
            // console.log("🚀 ~ useEffect ~ sessionIdFromUrl:", "caling verify payment  for times", i)
            // Verify the payment status with the backend
            verifyPayment(sessionIdFromUrl);
        
        }
    }, []);

    const verifyPayment = async (sessionId) => {
        try {
            // Call your backend to verify the payment status
            // const response = await axios.get( 'http://localhost:7000/payment/verify', {
            //     params: { sessionId }
       
            // });
            
            const response = await axios.get(`https://subscribe.integraledger.com/api/payment/verify`, {
                params: { sessionId }
       
            });
            

            console.log("🚀 ~ verifyPayment ~ response 1:", response.data)
            console.log("🚀 ~ verifyPayment ~ response:", response.data.data.success)
            if (response.data.data.success)  {
                console.log("🚀 ~ useEffect ~ sessionIdFromUrl:", "inside success")
                setPaymentStatus('Payment Successful');
            } else {
                console.log("🚀 ~ useEffect ~ sessionIdFromUrl:", "inside failed")
                setPaymentStatus('Payment Failed');
            }
        } catch (error) {
            console.error('Error verifying payment:', error);
            setPaymentStatus('Error occurred while verifying payment');
        }
    };

    return (
        <div>
            <h1>{paymentStatus}</h1>
            {sessionId && (
                <p>Your session ID is: {sessionId}</p>
            )}
        </div>
    );
};

export default SuccessPage;
