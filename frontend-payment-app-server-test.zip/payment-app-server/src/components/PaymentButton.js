// import React from 'react';
// import axios from 'axios';

// const PaymentButton = () => {
//     const handlePayment = async () => {
//         const payload = {
//             emailId: 'user@example.com',
//             tokens: 10,
//             amount: 1, // Amount in cents, e.g., $10.00
//             integraPublicKeyId: 'integra-pub-key1'
//         };

//         const encodedPayload = btoa(JSON.stringify(payload));

//         try {
//             const response = await axios.get(`http://localhost:7000/payment/checkout`, {
//                 params: { data: encodedPayload }
          
//             });
//             console.log("🚀 ~ handlePayment ~ response:", response)
//             // Redirect to Stripe Checkout
//             window.location.href = response.data.url;
//         } catch (error) {
//             console.error('Error initiating payment:', error);
//         }
//     };

//     return (
//         <button onClick={handlePayment}>Purchase Tokens</button>
//     );
// };

// export default PaymentButton;



import React from 'react';
import axios from 'axios';
// import dotenv from 'dotenv'

// dotenv.config();

const PaymentButton = () => {
    const handlePayment = async () => {
        // Prepare the payload with all required fields
        const payload = {
            emailId: 'user1-test-server-1@yopmail.com',
            tokens: 10, // Ensure this matches the backend expectation
            integraPublicKeyId: '9eaff882-b220-42ff-b5b8-f0bee7dca00a',
            priceId: 'price_1Psk0eGxdkO4DZqdKL8vYewN', // Replace with your actual price ID
            name: 'user1-test-server-1',
            organizationid: 'org1-235656fe',
            isMainnet:true
        };

        try {
            // Send request to backend to create a checkout session
            console.log("🚀 ~ handlePayment ~ response:", process.env.REACT_APP_BACKEND_URL);
            // const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/payment/checkout`, payload);
            const response = await axios.post(`https://subscribe.integraledger.com/api/payment/checkout`, payload);
            // const response = await axios.post(` http://localhost:7000/payment/checkout`, payload);
            console.log("🚀 ~ handlePayment ~ response:", response)
           

            // Redirect to Stripe Checkout
            window.location.href = response.data.data.url;
        } catch (error) {
            console.error('Error initiating payment:', error);
        }
    };

    return (
        <button onClick={handlePayment}>Purchase Tokens</button>
    );
};

export default PaymentButton;
