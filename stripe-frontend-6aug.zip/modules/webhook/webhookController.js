import Stripe from 'stripe';
import axios from 'axios';
import { stripeSecretKey, Blockchain_url, AUCTORITAS_USERNAME, AUCTORITAS_PASSWORD, STRIPE_WEBHOOK_SECRET } from '../../config/config.js';
import SubscriptionPlan from '../../models/subscriptionPlans.js';
import subscriptionSession from '../../models/subscriptionSession.js'
import { responseStatus } from "../../core/constants/constant.js";


// Initialize Stripe with your secret key
const stripe = new Stripe(stripeSecretKey); // Replace with your Stripe secret key

export const handleStripeWebhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  console.log("🚀 ~ handleStripeWebhook ~ sig:", sig)
  const rawBody = req.body;
  console.log("TCL: handleStripeWebhook -> rawBody", rawBody)

  let event;
  try {

    event = stripe.webhooks.constructEvent(rawBody, sig, STRIPE_WEBHOOK_SECRET);
    const eventId = event.id;

    let eventObject, metadata, updatedPayment, integraPublicKeyId, tokens, isTokenCredited;

    console.log("TCL: handleStripeWebhook -> event.type", event.type)
    switch (event.type) {

      // case 'invoice.payment_succeeded': {
      //   console.log("invoice succeeded",event.data.object);
      //   break;
      // }


      case 'customer.subscription.updated':{

        console.log("inside subscriptio updated ");

        console.log("event dsata ");
        console.log(event.data.object);
        
        const updatedSubscription = event.data.object;
        const subscriptionId = updatedSubscription.id;
        const renewalId = event.id;
        const invoiceId = updatedSubscription.latest_invoice; // Adjust as needed



        // Check if this renewal has already been processed
        const existingRenewal = await SubscriptionRenewal.findOne({ renewalId });

        if (existingRenewal.tokensCredited) {
          console.log('Renewal already processed');
          return res.status(200).json({ status: 'success', message: 'Renewal already processed' });
        }

        // Fetch the latest invoice details if needed
        const invoice = await stripe.invoices.retrieve(invoiceId);

        if (invoice.paid) {
          const priceId = updatedSubscription.plan.id;

          const sessionData = await subscriptionSession.findOne({ 'subscriptionDetails.subscriptionId': subscriptionId });

          if (!sessionData) {
            return res.status(404).json({ status: 'failure', message: 'Subscription not found' });
          }

          console.log("");
          integraPublicKeyId = sessionData.metadata.IntegraId;
          console.log("");
          console.log("TCL: handleStripeWebhook -> integraPublicKeyId", integraPublicKeyId)
          console.log("");


          let subscriptionPlan = await SubscriptionPlan.findOne({ priceId: priceId });

          if (!subscriptionPlan) {
            console.log("");
            console.log('Subscription plan not found for priceId:', priceId);
            console.log("");
            return res.status(400).json({
              status: responseStatus.failure,
              message: 'Subscription plan not found',

            });
          }
          tokens = subscriptionPlan.numberOfTokens || metadata.tokens;

          // Create a new renewal record
          const newRenewal = await SubscriptionRenewal.create({
            renewalId,
            subscriptionId,
            renewalDate: Date.now(),
            tokensCredited: false,
            sessionId,
            invoiceDetails: {
              invoiceId: invoiceDetails.id,
              amountDue: invoiceDetails.amount_due / 100, // Convert from cents to dollars
              amountPaid: invoiceDetails.amount_paid / 100, // Convert from cents to dollars
              created: invoiceDetails.created * 1000, // Convert to milliseconds
              currency: invoiceDetails.currency,
              customerId: invoiceDetails.customer,
              customerEmail: invoiceDetails.customer_email,
              customerName: invoiceDetails.customer_name,
              invoiceUrl: invoiceDetails.url,
              invoicePdf: invoiceDetails.pdf_url,
              paid: invoiceDetails.paid,
              paymentIntent: invoiceDetails.payment_intent,
              status: invoiceDetails.status,
              statementDescriptor: invoiceDetails.statement_descriptor,
              subtotal: invoiceDetails.subtotal / 100, // Convert from cents to dollars
              total: invoiceDetails.total / 100 // Convert from cents to dollars
            },
            subscriptionDetails: {
              subscriptionId: updatedSubscription.id,
              created: updatedSubscription.created * 1000, // Convert to milliseconds
              currency: updatedSubscription.currency,
              status: updatedSubscription.status,
              currentPeriodStart: updatedSubscription.current_period_start * 1000, // Convert to milliseconds
              currentPeriodEnd: updatedSubscription.current_period_end * 1000, // Convert to milliseconds
              startDate: updatedSubscription.start_date * 1000, // Convert to milliseconds
              customerId: updatedSubscription.customer_id,
              defaultPaymentMethod: updatedSubscription.default_payment_method,
              latestInvoice: updatedSubscription.latest_invoice,
              items: updatedSubscription.items, // Adjust based on actual data structure
              planDetails: {
                planId: updatedSubscription.plan.id,
                created: updatedSubscription.plan.created * 1000, // Convert to milliseconds
                currency: updatedSubscription.plan.currency,
                interval: updatedSubscription.plan.interval,
                intervalCount: updatedSubscription.plan.interval_count,
                tokens: updatedSubscription.plan.tokens,
                product: updatedSubscription.plan.product,
                amount: updatedSubscription.plan.amount / 100, // Convert from cents to dollars
                quantity: updatedSubscription.plan.quantity,
              },
            },
          });

          console.log('Created new renewal record:', newRenewal);

        }



        // Fetch subscription record to check if tokens need to be credited

        // Credit tokens if not already credited
        if (!newRenewal.tokensCredited) {
          const tokenInfo = await creditTokens(integraPublicKeyId, tokens);

          await SubscriptionRenewal.findOneAndUpdate(
            { renewalId },
            { $set: { tokensCredited: true, integraPublicKeyData: tokenInfo } },
            { new: true }
          );

          await SubscriptionRenewal.findOneAndUpdate(
            { renewalId },
            { $set: { integraPublicKeyData: tokenInfo } },
            { new: true }
          );

          console.log('Tokens credited for renewalId:', renewalId);
        }

        res.status(200).json({ status: 'success', message: 'Subscription renewal processed' });
        break;

      }
      case 'checkout.session.completed': {
        const session = event.data.object;
        console.log("TCL: handleStripeWebhook -> session", session)

        console.log("")

        let invoiceId = session.invoice;
        console.log("TCL: handleStripeWebhook -> session", session.invoice)

        console.log("");
        const invoice = await stripe.invoices.retrieve(invoiceId);
        console.log("TCL: handleStripeWebhook -> invoice", invoice)

        console.log("");
        metadata = session.metadata;
        console.log('Session metadata:', metadata);

        console.log("");
        console.log("subscription data ", invoice.subscription_details);

        const subscription = await stripe.subscriptions.retrieve(invoice.subscription)
        console.log("");
        console.log("🚀 ~ handleStripeWebhook ~ subscription:", subscription)
        console.log("");
        console.log("subscription data ", subscription.items.data);

        console.log("");



        if (invoice.paid) {

          const priceId = subscription.plan.id;
          let subscriptionPlan = await SubscriptionPlan.findOne({ priceId: priceId });

          if (!subscriptionPlan) {
            console.log("");
            console.log('Subscription plan not found for priceId:', priceId);
            console.log("");
            return res.status(400).json({
              status: responseStatus.failure,
              message: 'Subscription plan not found',

            });
          }
          tokens = subscriptionPlan.numberOfTokens || metadata.tokens;
          console.log("");
          console.log("TCL: handleStripeWebhook -> tokens", tokens)
          console.log("");
          console.log("metadata", metadata);

          let sessionData = await subscriptionSession.findOne({ sessionId: session.id });
          console.log("");
          console.log("🚀 ~ handleStripeWebhook ~ sessionData:", sessionData)

          if (!sessionData) {
            console.log('session data not found');
            return res.status(400).json({
              status: responseStatus.failure,
              message: 'session data not found',

            });
          }

          integraPublicKeyId = sessionData.metadata.IntegraId;
          console.log("");
          console.log("TCL: handleStripeWebhook -> integraPublicKeyId", integraPublicKeyId)
          console.log("");
          isTokenCredited = sessionData.isTokenCredited;

          console.log("");

          console.log("TCL: handleStripeWebhook -> event.id", event.id)
          console.log("");
          console.log("TCL: handleStripeWebhook -> event", event.type)
          console.log("");
          updatedPayment = await subscriptionSession.findOneAndUpdate(
            { sessionId: session.id }, // Query
            {
              $set: {
                customerId: session.customer,
                eventId: event.id,
                eventType: event.type,
                paymentIntent: session.payment_intent,
                status: session.status,
                invoiceId: session.invoice,
                invoiceDetails: {
                  invoiceId: invoice.id,
                  amountDue: invoice.amount_due / 100,
                  amountPaid: invoice.amount_paid / 100,
                  created: invoice.created,
                  currency: invoice.currency,
                  customer: invoice.customer,
                  customerEmail: invoice.customer_email,

                  customerName: invoice.customer_name,
                  InvoiceUrl: invoice.hosted_invoice_url,
                  invoicePdf: invoice.invoice_pdf,
                  status: invoice.status,
                  paid: invoice.paid,
                  payment_intent: invoice.payment_intent,
                  subtotal: invoice.subtotal,
                  total: invoice.total
                }
                , subscriptionDetails: {
                  subscriptionId: invoice.subscription,
                  created: subscription.created,
                  currency: subscription.currency,
                  status: subscription.status,
                  currentPeriodStart: subscription.current_period_start,
                  currentPeriodEnd: subscription.current_period_end,
                  startDate: subscription.start_date,
                  customerId: subscription.customer,
                  default_payment_method: subscription.default_payment_method,
                  latest_invoice: subscription.latest_invoice,
                  items: subscription.items
                  , planDetails: {
                    planId: subscription.plan.id,
                    created: subscription.plan.created,
                    currency: subscription.plan.currency,
                    interval: subscription.plan.interval,
                    interval_count: subscription.plan.interval_count,
                    tokens: tokens,
                    product: subscription.plan.product,
                    amount: subscription.plan.amount / 100,
                    quantity: subscription.plan.quanitity
                  }
                },
              }
            },
            { new: true } // Return the updated document
          );
        }


        console.log("");


        console.log("");

        if (!isTokenCredited) {

          const tokenInfo = await creditTokens(integraPublicKeyId, tokens);


          updatedPayment = await subscriptionSession.findOneAndUpdate(
            { sessionId: session.id }, // Query
            {
              $set: {
                isTokenCredited: true,
              }
            },
            { new: true } // Return the updated document
          );

          updatedPayment = await subscriptionSession.findOneAndUpdate(
            { sessionId: session.id }, // Query
            {
              $set: {
                integraPublicKeyData: tokenInfo
              }
            },
            { new: true } // Return the updated document
          );
          console.log("");

          console.log("tokens added in blockchain for integrapublic key ", integraPublicKeyId);
          console.log("updated db", updatedPayment);

        } else {
          console.log("");

          console.log("tokens already added in blockchain", integraPublicKeyId);
        }

      }


        break;


      default:
        console.log(`Unhandled event type ${event.type}`);
        return res.status(400).end();






    }

    res.status(200).json({ received: true });
  } catch (err) {
    console.error('Webhook error:', err.message);
    return res.status(400).json({
      responseStatus: false,
      message: `Webhook Error: ${err.message}`,
    });
  }












  async function creditTokens(integraPublicKeyId, tokens) {

    try {


      let auth_token;

      const authResponse = await axios.post(`${Blockchain_url}/auctoritas`, {
        username: AUCTORITAS_USERNAME,
        password: AUCTORITAS_PASSWORD
      });
      console.log("TCL: handleStripeWebhook -> authResponse", authResponse.status)

      if (authResponse && authResponse.status === 200 && authResponse.data.message === "success" && authResponse.data.token) {
        console.log("inside auctroritas if condition");
        auth_token = authResponse.data.token;
        console.log("TCL: handleStripeWebhook -> auth_token", auth_token)
      } else {
        return res.status(500).json({ status: 'failure', message: 'Error getting authentication token', data: {} });

      }
      console.log("");

      console.log("auth_token", auth_token);

      console.log("");

      console.log('Payload:', {
        IntegraID: integraPublicKeyId,
        Amount: tokens,
        Issue: false
      });
      // Add tokens to blockchain



      const addTokenResponse = await axios.post(`${Blockchain_url}/addToken`, {
        IntegraID: integraPublicKeyId,
        Amount: tokens,
        Issue: false
      }, {
        headers: {
          'Authorization': `Bearer ${auth_token}`
        }
      });

      console.log("");
      delete addTokenResponse.data.data.KeyValue
      console.log("🚀 ~ addToken response:", addTokenResponse.data);
      console.log("");

      let tokenAddedDate = Date.now()
      console.log("🚀 ~ handleStripeWebhook ~ tokenAddedDate:", tokenAddedDate)
      addTokenResponse.data.data.tokenAdditionTime = tokenAddedDate;
      console.log("");

      console.log("🚀 ~ handleStripeWebhook ~ addTokenResponse.data.data:", addTokenResponse.data.data)
      return addTokenResponse.data.data
    } catch (error) {
      res.status(500).json({ status: 'failure', message: 'Subscription renewal not processed' });
    }

  }








}
